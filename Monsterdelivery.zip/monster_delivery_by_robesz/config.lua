-- config.lua (monsterdelivery) by Robesz

Config = {}

-- Felvételi pont (postás NPC itt lesz)
Config.StartPoint = vector4(113.7328, -1087.7437, 29.1944, 316.3136)

-- Blip beállítások (felvételi pont)
Config.BlipSprite = 67 -- futárkocsi ikon
Config.BlipColor = 5
Config.JobName = "Futár"

-- Jármű spawn hely (amikor munkát veszel fel, ide spawnol a jármű és beültet)
Config.VehicleModel = "boxville2"
Config.VehicleSpawn = vector4(135.8357, -1082.0404, 29.1938, 358.4967)

-- Blip beállítások (felvételi pont)
Config.BlipSprite = 67 -- futárkocsi ikon
Config.BlipColor = 5
Config.JobName = "Futár"

-- Doboz modell
Config.BoxModel = "prop_cs_cardbox_01"

-- Távolságok (m)
Config.PickupDistance = 2.0
Config.DeliverDistance = 3.0

-- Fizetés
Config.Payment = 5000

-- Fizetés mód: true = bank (bank account), false = készpénz
Config.UseBank = false

-- Leadási pontok (vektorok). Ezeket véletlensorrendben kapja meg a játékos,
-- és nem ismétlődnek. Ügyeltem rá, hogy ne legyenek tetőn vagy út közepén.
Config.Recipients = {
    vector4(-415.8218, 99.0718, 64.2609, 236.9898),
    vector4(847.1176, -1017.6802, 27.8773, 351.3754),
    vector4(1312.4226, -1649.7090, 52.1455, 312.8548),
    vector4(88.5243, -1301.3894, 29.2336, 152.7404),
    vector4(193.3597, -1465.0409, 29.1368, 313.3203),
    vector4(1216.2811, -1381.9761, 35.3432, 218.2535),
    vector4(-499.7969, 276.2567, 83.2665, 175.8155),
    vector4(-1050.6157, -906.3384, 4.3090, 32.4715),
    vector4(330.8885, 345.8482, 105.2939, 166.5854),
    vector4(-97.6599, 428.5510, 113.0624, 269.6419),
    vector4(-688.5120, 597.7072, 143.6423, 46.5739),
    vector4(214.9300, 621.3521, 187.5305, 79.5933),
    vector4(1174.1071, -300.2519, 69.0445, 273.0961),
    vector4(-1291.0353, -1235.5927, 4.4539, 278.3989),
    vector4(419.4688, -2062.6108, 22.1258, 52.9968),
    vector4(856.1937, -2277.1428, 30.3420, 105.1041)
}

-- Lehetséges leadási NPC-modellek (véletlen választás)
-- include canonical model names (player_zero = Michael, player_one = Franklin, player_two = Trevor, cs_lestercrest = Lester, ig_floyd, ig_barry...)
Config.RecipientModels = {
    "player_zero",       -- Michael
    "player_one",        -- Franklin
    "player_two",        -- Trevor
    "cs_lestercrest",    -- Lester
    "ig_floyd",          -- Floyd
    "ig_barry",          -- Barry
    "ig_joeminuteman"    -- Joe
}

-- Felvételi NPC modellek (véletlenszerű postás kinézet)
Config.PostalModels = {
    "s_m_m_postal_01",
    "s_m_m_postal_02",
    "ig_postal"
}
