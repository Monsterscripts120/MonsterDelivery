-- server.lua (monsterdelivery) by robsz
-- ESX detektálás + biztonságos fizetés (bank/cash)

local ESX = nil

-- Try exports (ESX Legacy)
if exports and exports["es_extended"] and exports["es_extended"].getSharedObject then
    ESX = exports["es_extended"]:getSharedObject()
end

-- Fallback a régi event-re
if not ESX then
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
end

if not ESX then
    print("[monsterdelivery - robsz] HIBA: ESX objektum nem található! Ellenőrizd az es_extended resource-ot.")
else
    print("[monsterdelivery - robsz] ESX inicializálva.")
end

RegisterServerEvent('monsterdelivery:payPlayer')
AddEventHandler('monsterdelivery:payPlayer', function(amount)
    local src = source
    if not ESX then
        print(('[monsterdelivery - robsz] HIBA: ESX nil, nem lehet fizetni ID=%s'):format(src))
        return
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then
        print(('[monsterdelivery - robsz] HIBA: xPlayer nem található ID=%s'):format(src))
        return
    end

    amount = tonumber(amount) or 0
    if amount <= 0 then
        print(('[monsterdelivery - robsz] HIBA: érvénytelen összeg: %s'):format(tostring(amount)))
        return
    end

    if Config.UseBank then
        if xPlayer.addAccountMoney then
            xPlayer.addAccountMoney('bank', amount)
            TriggerClientEvent('esx:showNotification', src, ('Csomag kézbesítve! $%s jóváírva a bankszámládon. (by robsz)'):format(amount))
            print(('[monsterdelivery - robsz] Fizetés bankba: %s kapott $%s'):format(xPlayer.getName(), amount))
        else
            -- fallback
            xPlayer.addMoney(amount)
            TriggerClientEvent('esx:showNotification', src, ('Csomag kézbesítve! Kaptál $%s (fallback). (by robsz)'):format(amount))
            print(('[monsterdelivery - robsz] Fizetés (fallback cash): %s kapott $%s'):format(xPlayer.getName(), amount))
        end
    else
        if xPlayer.addMoney then
            xPlayer.addMoney(amount)
            TriggerClientEvent('esx:showNotification', src, ('Csomag kézbesítve! Kaptál $%s. (by robsz)'):format(amount))
            print(('[monsterdelivery - robsz] Fizetés cash: %s kapott $%s'):format(xPlayer.getName(), amount))
        else
            -- fallback to bank
            if xPlayer.addAccountMoney then
                xPlayer.addAccountMoney('bank', amount)
                TriggerClientEvent('esx:showNotification', src, ('Csomag kézbesítve! $%s jóváírva a bankszámládon. (by robsz)'):format(amount))
                print(('[monsterdelivery - robsz] Fizetés bank (fallback): %s kapott $%s'):format(xPlayer.getName(), amount))
            else
                print(('[monsterdelivery - robsz] HIBA: Nem sikerült fizetni %s-nek.'):format(xPlayer.getName()))
            end
        end
    end
end)
