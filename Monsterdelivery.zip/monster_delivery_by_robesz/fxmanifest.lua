fx_version 'cerulean'
game 'gta5'

author 'Robesz'
description 'MonsterDelivery - Futár munka (robesz)'
version '3.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
