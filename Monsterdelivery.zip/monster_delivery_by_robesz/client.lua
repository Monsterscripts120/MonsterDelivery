-- client.lua (monsterdelivery) by robsz
local ESX = exports["es_extended"]:getSharedObject()

-- Postás NPC spawn a felvételi ponton
Citizen.CreateThread(function()
    local model = GetHashKey("s_m_m_postal_01") -- postás modell
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(10)
    end

    local npc = CreatePed(4, model, Config.StartPoint.x, Config.StartPoint.y, Config.StartPoint.z - 1.0, Config.StartPoint.w, false, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    FreezeEntityPosition(npc, true)
    TaskStartScenarioInPlace(npc, "WORLD_HUMAN_CLIPBOARD", 0, true)
end)

local OnJob = false
local JobVehicle = nil
local CarryingBox = false
local DeliveryBlip = nil
local DeliveryQueue = {}       -- array of recipient tables in random order
local CurrentIndex = 0
local CurrentRecipient = nil
local RecipientPeds = {}       -- store ped handles per recipient
local BoxEntity = nil
local StartNPC = nil

-- Helper: request and load model
local function LoadModel(hash)
    if not IsModelInCdimage(hash) then return false end
    RequestModel(hash)
    local t = 0
    while not HasModelLoaded(hash) and t < 1000 do
        t = t + 1
        Wait(10)
    end
    return HasModelLoaded(hash)
end

-- Helper: shuffle
local function Shuffle(t)
    local n = #t
    for i = n, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
end

-- Draw 3D text
local function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 120)
end

-- Blip létrehozása a felvételi ponthoz
Citizen.CreateThread(function()
    local blip = AddBlipForCoord(Config.StartPoint.x, Config.StartPoint.y, Config.StartPoint.z)
    SetBlipSprite(blip, Config.BlipSprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.9)
    SetBlipColour(blip, Config.BlipColor)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.JobName)
    EndTextCommandSetBlipName(blip)
end)

-- Create/prepare delivery queue and spawn NPCs at targets (pre-spawn)
local function PrepareDeliveryQueue()
    -- copy recipients into queue
    DeliveryQueue = {}
    for i=1, #Config.Recipients do
        local rec = Config.Recipients[i]
        -- ensure ground z
        local x, y, z, w = rec.x, rec.y, rec.z, rec.w
        local found, groundZ = GetGroundZFor_3dCoord(x, y, z, 0)
        if found then z = groundZ end
        table.insert(DeliveryQueue, { pos = vector4(x, y, z, w), ped = nil })
    end

    -- shuffle so order random and no repeats
    Shuffle(DeliveryQueue)

    -- spawn peds at each delivery point (keep them until delivered)
    for i=1, #DeliveryQueue do
        local rec = DeliveryQueue[i]
        -- pick random model from Config.RecipientModels
        local modName = Config.RecipientModels[ math.random(1, #Config.RecipientModels) ]
        local modHash = GetHashKey(modName)
        if LoadModel(modHash) then
            local x, y, z, h = rec.pos.x, rec.pos.y, rec.pos.z, rec.pos.w
            local ped = CreatePed(4, modHash, x, y, z - 1.0, h, false, true)
            SetEntityInvincible(ped, true)
            SetBlockingOfNonTemporaryEvents(ped, true)
            TaskStartScenarioInPlace(ped, "WORLD_HUMAN_STAND_IMPATIENT", 0, true)
            rec.ped = ped
            RecipientPeds[#RecipientPeds + 1] = ped
        end
    end
end

-- Clear recipient peds
local function ClearAllRecipientPeds()
    for _, ped in ipairs(RecipientPeds) do
        if DoesEntityExist(ped) then
            DeletePed(ped)
        end
    end
    RecipientPeds = {}
end

-- Start job: spawn vehicle (player is warped into driver seat) and prep queue
local function StartJob()
    if OnJob then return end
    local playerPed = PlayerPedId()

    -- spawn vehicle (use ESX.Game.SpawnVehicle if available, else native)
    local modelHash = GetHashKey(Config.VehicleModel)
    if not LoadModel(modelHash) then
        ESX.ShowNotification("Hiba: jármű modell nem érhető el.")
        return
    end

    -- prepare queue and spawn recipient peds BEFORE vehicle spawn so they are visible
    PrepareDeliveryQueue()

    local x, y, z, h = Config.VehicleSpawn.x, Config.VehicleSpawn.y, Config.VehicleSpawn.z, Config.VehicleSpawn.w
    local found, groundZ = GetGroundZFor_3dCoord(x, y, z, 0)
    if found then z = groundZ + 0.5 end

    -- use ESX.Game.SpawnVehicle if available
    if ESX and ESX.Game and ESX.Game.SpawnVehicle then
        ESX.Game.SpawnVehicle(Config.VehicleModel, vector3(x, y, z), h, function(veh)
            JobVehicle = veh
            SetVehicleNumberPlateText(veh, "FUTAR")
            SetEntityAsMissionEntity(veh, true, true)
            TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
            OnJob = true
            ESX.ShowNotification("Megkezdted a futármunkát. A járműben vagy, vedd fel a csomagot a hátuljából.")
            -- set first waypoint to first queued recipient (if any)
            CurrentIndex = 1
            if DeliveryQueue[CurrentIndex] then
                local t = DeliveryQueue[CurrentIndex].pos
                if DeliveryBlip then RemoveBlip(DeliveryBlip) end
                DeliveryBlip = AddBlipForCoord(t.x, t.y, t.z)
                SetBlipRoute(DeliveryBlip, true)
                SetNewWaypoint(t.x, t.y)
                ESX.ShowNotification("Kövesd a GPS-et az első címre.")
            end
        end)
    else
        -- native spawn
        local veh = CreateVehicle(modelHash, x, y, z, h, true, false)
        JobVehicle = veh
        SetVehicleNumberPlateText(veh, "FUTAR")
        SetEntityAsMissionEntity(veh, true, true)
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        OnJob = true
        ESX.ShowNotification("Megkezdted a futármunkát. A járműben vagy, vedd fel a csomagot a hátuljából.")
        CurrentIndex = 1
        if DeliveryQueue[CurrentIndex] then
            local t = DeliveryQueue[CurrentIndex].pos
            if DeliveryBlip then RemoveBlip(DeliveryBlip) end
            DeliveryBlip = AddBlipForCoord(t.x, t.y, t.z)
            SetBlipRoute(DeliveryBlip, true)
            SetNewWaypoint(t.x, t.y)
            ESX.ShowNotification("Kövesd a GPS-et az első címre.")
        end
    end
end

-- End job: cleanup
local function EndJob()
    OnJob = false

    -- Delete vehicle if exists and is mission entity
    if JobVehicle and DoesEntityExist(JobVehicle) then
        SetEntityAsMissionEntity(JobVehicle, true, true)
        DeleteVehicle(JobVehicle)
        JobVehicle = nil
    end

    -- Delete any remaining box entity attached to player
    if BoxEntity and DoesEntityExist(BoxEntity) then
        DeleteEntity(BoxEntity)
        BoxEntity = nil
    end

    -- Remove blip
    if DeliveryBlip then RemoveBlip(DeliveryBlip) DeliveryBlip = nil end

    -- Clear recipient peds
    ClearAllRecipientPeds()

    CurrentIndex = 0
    DeliveryQueue = {}
    ESX.ShowNotification("Befejezted a munkát. Visszatértél a postára.")
end

-- Pickup box from vehicle rear (attach to player)
local function PickupBox()
    if CarryingBox then return end
    if not JobVehicle or not DoesEntityExist(JobVehicle) then
        ESX.ShowNotification("Nincs járműved.")
        return
    end

    local playerPed = PlayerPedId()
    local back = GetOffsetFromEntityInWorldCoords(JobVehicle, 0.0, -3.0, 0.5)
    local pCoords = GetEntityCoords(playerPed)
    if #(pCoords - back) > Config.PickupDistance then
        ESX.ShowNotification("Túl messze vagy a jármű hátuljától.")
        return
    end

    -- animation
    local animDict = "anim@heists@box_carry@"
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end
    TaskPlayAnim(playerPed, animDict, "idle", 8.0, -8.0, -1, 49, 0, false, false, false)

    -- create and attach box
    local boxHash = GetHashKey(Config.BoxModel)
    if not LoadModel(boxHash) then ESX.ShowNotification("Hiba: doboz modell nem található.") return end
    BoxEntity = CreateObject(boxHash, 0, 0, 0, true, true, true)
    AttachEntityToEntity(BoxEntity, playerPed, GetPedBoneIndex(playerPed, 60309), 0.02, 0.08, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    CarryingBox = true

    -- ensure current index exists
    if CurrentIndex == 0 then
        ESX.ShowNotification("Nincs kiszállítási cím beállítva.")
        return
    end

    -- set waypoint for current recipient
    local rec = DeliveryQueue[CurrentIndex]
    if rec then
        local t = rec.pos
        if DeliveryBlip then RemoveBlip(DeliveryBlip) end
        DeliveryBlip = AddBlipForCoord(t.x, t.y, t.z)
        SetBlipRoute(DeliveryBlip, true)
        SetNewWaypoint(t.x, t.y)
        ESX.ShowNotification("Kövesd a GPS-et a címzetthez.")
    end
end

-- Deliver the box to the current recipient
local function DeliverBox()
    if not CarryingBox or CurrentIndex == 0 then return end
    local playerPed = PlayerPedId()
    local rec = DeliveryQueue[CurrentIndex]
    if not rec then return end

    local recCoords = vector3(rec.pos.x, rec.pos.y, rec.pos.z)
    local pCoords = GetEntityCoords(playerPed)
    if #(pCoords - recCoords) > Config.DeliverDistance then
        ESX.ShowNotification("Túl messze vagy a leadási helytől.")
        return
    end

    -- play give animation
    ClearPedTasksImmediately(playerPed)
    local animDict = "mp_common"
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end
    TaskPlayAnim(playerPed, animDict, "givetake1_a", 8.0, -8.0, 1000, 49, 0, false, false, false)
    Wait(900)

    -- remove box
    if BoxEntity and DoesEntityExist(BoxEntity) then
        DeleteEntity(BoxEntity)
        BoxEntity = nil
    end
    CarryingBox = false

    -- pay player via server event
    TriggerServerEvent('monsterdelivery:payPlayer', Config.Payment)

    -- delete recipient ped
    if rec.ped and DoesEntityExist(rec.ped) then
        DeletePed(rec.ped)
        rec.ped = nil
    end

    -- remove blip for this delivery
    if DeliveryBlip then RemoveBlip(DeliveryBlip) DeliveryBlip = nil end

    -- move to next
    CurrentIndex = CurrentIndex + 1
    if CurrentIndex <= #DeliveryQueue then
        local nextRec = DeliveryQueue[CurrentIndex]
        if nextRec then
            SetNewWaypoint(nextRec.pos.x, nextRec.pos.y)
            DeliveryBlip = AddBlipForCoord(nextRec.pos.x, nextRec.pos.y, nextRec.pos.z)
            SetBlipRoute(DeliveryBlip, true)
            ESX.ShowNotification("Kövesd a GPS-et a következő címre.")
        end
    else
        -- finished all deliveries
        ESX.ShowNotification("Minden csomagot kézbesítettél! Visszatérhetsz a postára.")
        EndJob()
    end
end

-- Main loops: interactions
Citizen.CreateThread(function()
    while true do
        Wait(0)

        -- show E prompt at StartPoint (interact with StartNPC)
        local playerPed = PlayerPedId()
        local pCoords = GetEntityCoords(playerPed)
        local startCoords = vector3(Config.StartPoint.x, Config.StartPoint.y, Config.StartPoint.z)
        if #(pCoords - startCoords) < 3.0 then
            -- Ensure StartNPC exists (it was spawned in thread at resource start)
            DrawText3D(Config.StartPoint.x, Config.StartPoint.y, Config.StartPoint.z + 1.0, "~g~E~w~ - Munka felvétele (postás)")
            if IsControlJustReleased(0, 38) then
                -- Toggle job
                if not OnJob then
                    -- start job
                    StartJob()
                else
                    -- if already OnJob, allow player to stop job (clean up)
                    EndJob()
                end
            end
        end

        -- If on job and vehicle exists, handle pickup / deliver keys
        if OnJob and JobVehicle and DoesEntityExist(JobVehicle) then
            local backPos = GetOffsetFromEntityInWorldCoords(JobVehicle, 0.0, -3.0, 0.0)
            local playerCoords = GetEntityCoords(PlayerPedId())

            -- Pickup prompt
            if not CarryingBox and #(playerCoords - backPos) < Config.PickupDistance then
                DrawText3D(backPos.x, backPos.y, backPos.z + 0.6, "~g~H~w~ - Doboz felvétele")
                if IsControlJustReleased(0, 74) then
                    PickupBox()
                end
            end

            -- Deliver prompt
            if CarryingBox and CurrentIndex > 0 and DeliveryQueue[CurrentIndex] then
                local target = DeliveryQueue[CurrentIndex].pos
                local distToTarget = #(playerCoords - vector3(target.x, target.y, target.z))
                if distToTarget < Config.DeliverDistance then
                    DrawText3D(target.x, target.y, target.z + 1.0, "~g~H~w~ - Doboz átadása")
                    if IsControlJustReleased(0, 74) then
                        DeliverBox()
                    end
                end
            end
        end
    end
end)

-- Clean up when resource stops
AddEventHandler('onResourceStop', function(resName)
    if resName == GetCurrentResourceName() then
        -- delete vehicle
        if JobVehicle and DoesEntityExist(JobVehicle) then
            DeleteVehicle(JobVehicle)
        end
        -- delete start NPC
        if StartNPC and DoesEntityExist(StartNPC) then
            DeletePed(StartNPC)
        end
        -- delete any recipient peds
        ClearAllRecipientPeds()
    end
end)

-- >>> POSTÁS RUHA SCRIPT <<<

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    if job.name == 'postas' then
        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
            local clothesSkin = {
                ['tshirt_1'] = 15,  ['tshirt_2'] = 0,
                ['torso_1'] = 65,  ['torso_2'] = 0,
                ['arms'] = 11,
                ['pants_1'] = 38,  ['pants_2'] = 0,
                ['shoes_1'] = 25,  ['shoes_2'] = 0,
                ['helmet_1'] = 13, ['helmet_2'] = 0
            }

            if skin.sex == 0 then
                TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
            else
                local femaleClothes = {
                    ['tshirt_1'] = 3,  ['tshirt_2'] = 0,
                    ['torso_1'] = 73,  ['torso_2'] = 0,
                    ['arms'] = 5,
                    ['pants_1'] = 36,  ['pants_2'] = 0,
                    ['shoes_1'] = 27,  ['shoes_2'] = 0,
                    ['helmet_1'] = 14, ['helmet_2'] = 0
                }
                TriggerEvent('skinchanger:loadClothes', skin, femaleClothes)
            end
            ESX.ShowNotification("Felvetted a postás egyenruhát 📮")
        end)
    else
        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
            TriggerEvent('skinchanger:loadSkin', skin)
            ESX.ShowNotification("Visszavetted a civil ruhád 👕")
        end)
    end
end)
